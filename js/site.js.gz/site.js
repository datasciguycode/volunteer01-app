function getLocationHash()
{
    return window.location.hash;
}
